class Account {
  String user;
  String password;

  Account(this.user, this.password);
}
