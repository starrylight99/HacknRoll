class Participant {
  String studentId;
  String afkTime;
  String afkCount;
  String status;

  Participant(this.studentId, this.afkTime, this.afkCount, this.status);
}
