import 'package:flutter/material.dart';
import 'package:focusv2/Components/account.dart';
import 'package:focusv2/Components/alreadyHaveAnAccount.dart';
import 'package:focusv2/Components/roundedButton.dart';
import 'package:focusv2/Components/roundedInputField.dart';
import 'package:focusv2/Components/roundedPasswordField.dart';
import 'package:focusv2/Signup/Components/background.dart';
import 'package:focusv2/color.dart';

class Body extends StatefulWidget {
  @override
  _BodyState createState() => _BodyState();
}

class _BodyState extends State<Body> {
  String userId;
  String passWord;
  Account details = new Account('.', '.');
  bool idClash = false;
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Background(
        child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
          Text(
            "Sign Up",
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          SizedBox(height: size.height * 0.03),
          RoundedInputField(
            hintText: "Your Email",
            onChanged: (value) {
              userId = value;
            },
          ),
          RoundedPasswordField(
            onChanged: (value) {
              passWord = value;
            },
          ),
          RoundedButton(
              text: "Sign Up",
              press: () {
                details.user = userId;
                details.password = passWord;
                if (true) {
                  print('1');
                  idClash = false;
                  Navigator.pop(context);
                } else {
                  print('2');
                  setState(() {
                    idClash = true;
                  });
                }
              },
              color: idClash ? Colors.red : kPrimaryColor),
          SizedBox(height: size.height * 0.03),
          AlreadyHaveAnAccountCheck(
              login: false,
              press: () {
                Navigator.pop(context);
              })
        ]));
  }
}
