import 'package:flutter/material.dart';
import 'package:focusv2/Components/roundedButton.dart';
import 'package:focusv2/Login/login.dart';
import 'package:focusv2/Welcome/components/background.dart';
import 'package:focusv2/color.dart';

class Body extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Background(
      child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text('WTF i cant see anything?',
                style: TextStyle(fontWeight: FontWeight.bold)),
            SizedBox(height: size.height * 0.1),
            RoundedButton(
                text: 'Login',
                press: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) {
                    return LoginScreen();
                  }));
                }),
            RoundedButton(
                text: 'Login',
                color: kPrimaryLightcolor,
                textColor: Colors.black,
                press: () {})
          ]),
    );
  }
}
