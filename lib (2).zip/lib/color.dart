import 'package:flutter/material.dart';

const kPrimaryColor = Color(0xFF03A9F4);
const kPrimaryLightcolor = Color(0xFFB3E5FC);
