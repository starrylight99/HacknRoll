var useridlist = ['abc', 'def', 'ghi'];
var passwordslist = ['123', '456', '789'];
