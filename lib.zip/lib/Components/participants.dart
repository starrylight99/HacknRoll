class Participants {
  String appUser;
  bool switchedOn = false;
  bool isActive = false;

  Participants();

  void checkSwitchedOn() {}
}
