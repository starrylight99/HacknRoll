import 'package:flutter/material.dart';
import 'package:focusv2/Welcome/components/body.dart';

class WelcomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(body: Body());
  }
}
